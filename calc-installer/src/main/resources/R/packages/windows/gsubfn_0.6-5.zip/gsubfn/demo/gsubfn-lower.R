
# makes all letters except first in word lower case
gsubfn("\\B.", tolower, "I LIKE A BANANA SPLIT", perl = TRUE)

