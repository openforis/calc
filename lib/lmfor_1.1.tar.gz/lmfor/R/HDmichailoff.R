HDmichailoff <-
function(d,a,b,bh=1.3) {
    a*exp(-b*d^(-1))+bh
}
