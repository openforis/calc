startHDcurtis <-
function(d,h,bh=1.3) {
    start<-coef(lm(log(h)~log(d/(1+d))))
    start[1]<-exp(start[1])
    names(start)<-c("a","b")
    start
}
