NRnum <-
function(init, fnlist, crit=6,...) {
    par<-init
    #        sapply(par,function(x) cat(x," "))
    #        cat("\n")
    value<-sapply(fnlist,function(f) f(par,...))
    j<-1
    while (round(sum(abs(value)),crit)!=0&j<100) {
        #              cat(j,"\n")
        grad<-t(sapply(fnlist,function(f) attributes(numericDeriv(quote(f(par)),c("par")))$gradient))
        deltax<-solve(grad,-value)
        par<-par+deltax
        #              sapply(par,function(x) cat(x," "))
        #              cat("\n")
        value<-sapply(fnlist,function(f) f(par,...))
        j<-j+1
    }
    if (j<100) {
        list(par=par,value=value)
    } else {
        list(par=NA,value=NA)
    }
}
