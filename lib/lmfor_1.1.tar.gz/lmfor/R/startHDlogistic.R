startHDlogistic <-
function(d,h,bh=1.3) {
    a<-1.3*max(h-bh)
    start<-c(a,coef(lm(log((a-h+bh)/(h-bh))~d)))
    start[2]<-exp(start[2])
    start[3]<--start[3]
    names(start)<-c("a","b","c")
    start
}
