HDcurtis <-
function(d,a,b,bh=1.3) {
    a*(d/(1+d))^b+bh
}
