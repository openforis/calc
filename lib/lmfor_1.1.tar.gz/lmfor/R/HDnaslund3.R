HDnaslund3 <-
function (d, a, b, bh = 1.3) {
    d^2/(exp(a) + b * d)^2 + bh
}
