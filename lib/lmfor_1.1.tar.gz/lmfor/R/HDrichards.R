HDrichards <-
function(d,a,b,c,bh=1.3) {
    a*(1-exp(-b*d))^c+bh
}
