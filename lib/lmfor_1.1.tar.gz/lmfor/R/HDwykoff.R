HDwykoff <-
function(d,a,b,bh=1.3) {
    exp(a+b/(d+1))
}
