startHDratkowsky <-
function(d,h,bh=1.3,c=5) {
    start<-c(coef(lm(log(h-bh)~I(1/(d+c)))),c)
    start[1]<-exp(start[1])
    start[2]<--start[2]
    names(start)<-c("a","b","c")
    start
}
