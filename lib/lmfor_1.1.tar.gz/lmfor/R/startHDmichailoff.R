startHDmichailoff <-
function(d,h,bh=1.3) {
    a<-1.3*max(h-bh)
    mod<-lm(log((h-bh))~I(1/d))
    start<-c(exp(coef(mod)[1]),-coef(mod)[2])
    names(start)<-c("a","b")
    start
}
