HDprodan <-
function(d,a,b,c,bh=1.3) {
    d^2/(a+b*d+c*d^2)+bh
}
