startHDsibbesen <-
function(d,h,bh=1.3,a=0.5) {
    start<-c(a,coef(lm(log(log((h-bh)/a)/log(d))~log(d))))
    start[2]<-exp(start[2])
    start[3]<--start[3]
    names(start)<-c("a","b","c")
    start
}
