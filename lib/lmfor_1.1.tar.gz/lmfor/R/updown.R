updown <-
function(l, u, fn, crit=6) {
    fnu<-fn(u)
    fnl<-fn(l)
    if (fnl*fnu>0) return(NA)
    value<-fn((u+l)/2)
    while (round(value,crit)!=0&(u-l)>10^(-crit)) {
        if (fnu*value>0) {
            u<-(u+l)/2 
            fnu<-value 
        } else {
            l<-(u+l)/2
            fnl<-value
        }
        value<-fn((u+l)/2) 
        #              cat(l,fnl,u,fnu,"\n")
    }
    nollakohta<-(l+u)/2
    nollakohta
}
