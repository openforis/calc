HDratkowsky <-
function(d,a,b,c,bh=1.3) {
    val<-a*exp(-b/(d+c))+bh
    #     print(a,b,c)
    #         points(d,val,col="green")
    val
}
