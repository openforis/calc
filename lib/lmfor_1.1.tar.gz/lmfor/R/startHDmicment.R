startHDmicment <-
function(d,h,bh=1.3) {
    tmp<-coef(lm(I(d/(h-bh))~d))
    start<-c(1/tmp[2],tmp[1]/tmp[2])
    names(start)<-c("a","b")
    start
}
