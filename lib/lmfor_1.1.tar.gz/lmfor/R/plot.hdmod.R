plot.hdmod <-
function(model,col.point="blue",highlight="red",standd=TRUE,cex=1) {
    res<-resid(model,type="p")
    d<-attributes(model)$d
    plot<-attributes(model)$plot
    plots<-unique(plot)
    dstd<-d
    
    
    # compute diameter that is standardized for each plot
    if (standd) {
        for (i in 1:length(plots)) {
            # thisplot will include observations only from i:th plot
            dthis<-d[plot==plots[i]]
            dstd[plot==plots[i]]<-(dthis-mean(dthis))/sd(dthis)
        }
        plot(dstd,
             res,
             col=col.point,cex=cex,
             main=paste(attributes(model)$model,"s.e.=",round(sd(resid(model)),3)),
             xlab="Standwise standardized diameter",
             ylab="Standardized residual")
    } else {
        plot(dstd,
             res,
             col=col.point,cex=cex,
             main=paste(attributes(model)$model,"s.e.=",round(sd(resid(model)),3)),
             xlab="Diameter, cm",
             ylab="Standardized residual")
    }
    mywhiskers(dstd,res,add=TRUE,highlight="black",se=FALSE)
    mywhiskers(dstd,res,add=TRUE,highlight=highlight,lwd=3)
    abline(0,0)
}
