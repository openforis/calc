startHDhossfeldIV <-
function(d,h,bh=1.3,c=5) {
    a<-1.3*max(h-bh)
    start<-c(a,coef(lm(log(1/(a/h-1))~log(d))))
    start[2]<-exp(start[2])
    names(start)<-c("a","b","c")
    start
}
