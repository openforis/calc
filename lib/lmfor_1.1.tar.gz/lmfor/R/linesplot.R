linesplot <-
function(x, y, group, xlab="x", ylab="y", main="", cex=0.5, pch=19, col=1, col.lin=1, lw=FALSE, ylim=NULL, xlim=NULL, add=FALSE, lty="solid",lwd=1) {
    group<-group[order(x)]
    y<-y[order(x)]
    
    col<-rep(col,length(x))
    if (length(col.lin)==1) col.lin=rep(col.lin,length(x))
    col.lin<-col.lin[order(x)]
    
    if (length(lty)==1) lty=rep(lty,length(x))
    lty<-lty[order(x)]
    
    if (length(lwd)==1) lwd=rep(lwd,length(x))
    lwd<-lwd[order(x)]
    
    x<-x[order(x)]
    if (!add) {
        plot(x,y,type="n",xlab=xlab,ylab=ylab,main=main,cex=cex,pch=pch,col=col,ylim=ylim,xlim=xlim)
    }
    apu<-unique(group)
    for (i in 1:length(apu)) {
        print(col.lin[group==apu[i]])
        lines(x[group==apu[i]],y[group==apu[i]],col=col.lin[group==apu[i]],lty=lty[group==apu[i]],
              lwd=lwd[group==apu[i]])
    }
    points(x,y,col=col,cex=cex)
    if (lw) {
        apu<-unique(col)
        for (i in 1:length(apu))
            lines(lowess(x[col==apu[i]],y[col==apu[i]],f=0.5,iter=5),col=apu[i],lwd=3)
    }
}
