circle <-
function(x, y, r, col="black", lty="solid", lwd=1, grayfill=FALSE) {
    xapu<-sin(seq(0,pi,length=50)-pi/2)
    for (i in 1:length(x)) {
        if (grayfill) {
            xv1<-x[i]+xapu*r[i]/2
            xv2<-x[i]-xapu*r[i]/2
            yv1<-sqrt(pmax(0,(r[i]/2)^2-(xv1-x[i])^2))+y[i]
            yv2<--sqrt(pmax(0,(r[i]/2)^2-(xv2-x[i])^2))+y[i]
            yv<-c(yv1,yv2)
            xv<-c(xv1,xv2)
            lines(xv,yv,col="gray",lwd=5*r[i])               
        }
        xv1<-x[i]+xapu*r[i]
        xv2<-x[i]-xapu*r[i]
        yv1<-sqrt(pmax(0,r[i]^2-(xv1-x[i])^2))+y[i]
        yv2<--sqrt(pmax(0,r[i]^2-(xv2-x[i])^2))+y[i]
        yv<-c(yv1,yv2)
        xv<-c(xv1,xv2)
        lines(xv,yv,col=col,lty=lty,lwd=lwd)
    }
}
