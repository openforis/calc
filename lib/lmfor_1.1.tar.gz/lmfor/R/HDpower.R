HDpower <-
function(d,a,b,bh=1.3) {
    a*d^b+bh
}
