startHDrichards <-
function(d,h,bh=1.3,b=0.04) {
    start<-coef(lm(log(h-bh)~log(1-exp(-b*d))))
    start<-c(exp(start[1]),b,start[2])
    names(start)<-c("a","b","c")
    start
}
