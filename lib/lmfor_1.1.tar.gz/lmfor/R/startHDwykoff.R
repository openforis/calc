startHDwykoff <-
function(d,h,bh=1.3) {
    mod<-lm(log((h-bh))~I(1/d))
    start<-c(coef(mod)[1],coef(mod)[2])
    names(start)<-c("a","b")
    start
}
