HDmicment2 <-
function(d,a,b,bh=1.3) {
    d/(a+b*d)+bh
}
