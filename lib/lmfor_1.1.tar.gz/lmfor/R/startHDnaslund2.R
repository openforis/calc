startHDnaslund2 <-
function(d,h,bh=1.3) {
    start<-coef(lm(I(d/sqrt(h-bh))~d))
    start[2]<-log(start[2])
    names(start)<-c("a","b")
    start
}
