startHDkorf <-
function(d,h,bh=1.3) {
    a<-1.3*max(h-bh)
    y<-log(-log((h-bh)/a))
    startmod<-lm(y[is.finite(y)]~log(d)[is.finite(y)],na.action=na.omit)
    start<-c(a,exp(coef(startmod)[1]),-coef(startmod)[2])
    names(start)<-c("a","b","c")
    start
}
