startHDmeyer <-
function(d,h,bh=1.3) {
    a<-1.3*max(h-bh)
    b<--coef(lm(log(1-(h-bh)/a)~d-1))
    start<-c(a,b) 
    names(start)<-c("a","b")
    start
}
