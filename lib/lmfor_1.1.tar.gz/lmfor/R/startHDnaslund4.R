startHDnaslund4 <-
function (d, h, bh = 1.3) {
    start <- coef(lm(I(d/sqrt(h - bh)) ~ d))
    start[1]<-log(max(start[1],0.1))
    start[2]<-log(max(start[2],0.1))
    names(start) <- c("a", "b")
    start
}
