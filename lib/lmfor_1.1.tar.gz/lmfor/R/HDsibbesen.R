HDsibbesen <-
function(d,a,b,c,bh=1.3) {
    a*d^(b*d^(-c))+bh
}
