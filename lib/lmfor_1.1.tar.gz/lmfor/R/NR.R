NR <-
function(init, fn, gr, crit=6, range=c(-Inf,Inf)) {
    par<-init
    value<-fn(par)
    j<-1
    while (round(value,crit)!=0&j<100000) {
        grad<-gr(par)
        a<-value-grad*par
        par<--a/grad
        par<-min(max(par,range[1]),range[2])
        value<-fn(par)
        cat(par,value,"\n")
        j<-j+1
    }
    if (j<100000) {
        list(par=par,value=value)
    } else {
        list(par=NA,value=NA)
    }
}
