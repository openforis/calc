startHDpower <-
function(d,h,bh=1.3) {
    start<-coef(lm(log(h-bh)~log(d)))  # includes starting values estimates of a and b
    start[1]<-exp(start[1])
    names(start)<-c("a","b")
    start
}
