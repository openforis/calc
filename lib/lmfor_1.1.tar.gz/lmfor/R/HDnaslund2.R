HDnaslund2 <-
function(d,a,b,bh=1.3) {
    d^2/(a+exp(b)*d)^2+bh
}
