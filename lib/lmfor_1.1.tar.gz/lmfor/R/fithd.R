fithd <-
function(d,h,plot=c(),modelName="naslund",nranp=2,random=NA,varf=FALSE,na.omit=TRUE,start=NA,bh=1.3, control = list()) {
    
    if (!is.na(list(random))) nranp<-1
    
    if (na.omit) {
        sel<-is.na(h*d)
        d<-d[!sel]
        plot<-plot[!sel]
        h<-h[!sel]
    }
    
    # Linear model fitting              
    if (class(modelName)=="formula") { 
        modEq<-modelName
        if (!is.na(random)) {
            # If a formula is provided in ranp, use it.
            ranEq=as.formula(paste(deparse(random),"|plot"))
        } else if (nranp>0) {
            # Otherwise take the given number of trems of model from teh beginning. 
            # Constant is always assumed to be the first if model just has it.
            ranTerms<-paste("+",attributes(terms(modelName))$term.labels,sep="")
            if (attributes(terms(modelName))$intercept) {
                ranTerms<-c("1",ranTerms)
                ranp<-1:nranp
            } else {
                ranTerms<-c("-1",ranTerms)
                ranp<-1:(nranp+1)
            }
            ranEq<-"~"
            for (j in ranp) {
                ranEq<-paste(ranEq,ranTerms[j],sep="")
            } 
            ranEq<-as.formula(paste(ranEq,"|plot",sep=""))
        } 
        
        
        if (!nranp) {
            if (varf) {
                mod<-gls(modEq, 
                         weights=varPower(-0.5,~d),
                         control=control)         
            } else { 
                mod<-gls(modEq,
                         control=control)
            }
        } else {
            if (varf) {
                mod<-lme(fixed=modEq, 
                         random=ranEq,
                         weights=varPower(-0.5,~d),
                         control=control)         
            } else { 
                mod<-lme(fixed=modEq, 
                         random=ranEq,
                         control=control)
            }
        }
        class(mod)<-c("hdmod",class(mod))
        attributes(mod)$model<-modelName
        attributes(mod)$d<-d
        attributes(mod)$h<-h
        attributes(mod)$plot<-plot
        mod$call[[2]]<-modEq
        if (nranp) mod$call[[3]]<-ranEq
        
    } else { 
        
        # Nonlinear model fitting
        if (is.na(start[1])) start<-eval(call(paste("startHD",modelName,sep=""),d=d,h=h,bh=bh))
        
        #        # The # of random parameters should not exceed the # of parameters
        #    ranp<-min(ranp,length(formals(paste("HD",model,sep="")))-2)
        
        if (!is.na(list(random))) {
            ranEq<-random
        } else if (nranp) {
            ranEq<-lapply(paste(names(formals(paste("HD",modelName,sep="")))[1+1:nranp],"~1",sep=""),as.formula)
        }
        
        #            if (nranp==1) {
        #               ranEq<-list(a~1)
        #               } else if (nranp==2) {
        #               ranEq<-list(a~1,b~1)
        #               } else if (nranp==3) {
        #               ranEq<-list(a~1,b~1,c~1)
        #               }
        
        if (length(formals(paste("HD",modelName,sep="")))==5) {
            #     if (modelName=="korf3") {
            modEq<-as.formula(paste("h~HD",modelName,"(d,a,b,c,bh=",bh,")",sep=""))
            fixEq<-list(as.formula("a~1"),as.formula("b~1"),as.formula("c~1"))
        } else {
            modEq<-as.formula(paste("h~HD",modelName,"(d,a,b,bh=",bh,")",sep=""))
            fixEq<-list(as.formula("a~1"),as.formula("b~1"))
        }
        
        
        
        if (!nranp) {
            if (!varf) {
                mod<-gnls(modEq,
                          start=start,
                          control=control
                )
            } else {
                mod<-gnls(modEq,
                          start=start,
                          weights=varPower(-0.5,~d),
                          control=control
                )                 
            }
        } else {              
            if (!varf) {
                mod<-nlme(modEq,
                          fixed=fixEq,
                          random=ranEq,
                          groups=~plot,
                          start=start,
                          control=control)
            } else {
                mod<-nlme(modEq,
                          fixed=fixEq,
                          random=ranEq,
                          groups=~plot,
                          start=start,
                          weights=varPower(-0.5,~d),
                          control=control)
            }
        }
        class(mod)<-c("hdmod",class(mod))
        attributes(mod)$model<-modelName
        attributes(mod)$d<-d
        attributes(mod)$h<-h
        attributes(mod)$plot<-plot
        mod$call[[2]]<-modEq
        mod$call[[3]]<-fixEq
        if (nranp) mod$call[[4]]<-ranEq
    }
    mod
}
