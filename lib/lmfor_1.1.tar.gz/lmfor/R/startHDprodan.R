startHDprodan <-
function(d,h,bh=1.3) {
    start<-coef(lm(I(d^2/(h-bh))~d+I(d^2)))
    names(start)<-c("a","b","c")
    start
}
