qqplotHD <-
function(model,startnew=TRUE) {
    res<-resid(model,type="p")
    
    if (sum(class(model)=="lme")) {
        rem<-ranef(model)
        nplots<-dim(rem)[2]+1
        if (startnew) { 
            par(mfcol=c(2,ceiling(nplots/2)))
            
        }                  
        qqnorm(res,main="N-QQ-plot of standardized residuals")
        qqline(res)
        sapply(1:dim(rem)[2],function(x) {qqnorm(rem[,x],main=paste("QQ-plot of",colnames(rem)[x])); qqline(rem[,x])})
    } else {
        qqnorm(res,main="N-QQ-plot of standardized residuals")
        qqline(res)
    }
}
