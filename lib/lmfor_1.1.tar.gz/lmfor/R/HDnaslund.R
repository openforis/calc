HDnaslund <-
function(d,a,b,bh=1.3) {
    d^2/(a+b*d)^2+bh
}
