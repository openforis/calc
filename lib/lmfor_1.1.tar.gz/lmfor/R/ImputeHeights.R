ImputeHeights <-
function(d, h, plot=c(),modelName="naslund",nranp=2, varf=TRUE, addResidual=FALSE, makeplot=TRUE, level=1, start=NA,bh=1.3,control=list(),random=NA) {
    
    data<-data.frame(d=d,h=h,plot=plot)
    data1<-data[!is.na(data$h*data$d),]
    
    mod<-fithd(data1$d,data1$h,data1$plot,
               modelName=modelName,nranp=nranp,random=random,
               varf=varf,start=start,bh=bh,control=control)                                       
    
    hplots<-unique(data$plot[!is.na(data$h*data$d)])
    type<-rep(2,dim(data)[1])
    for (i in 1:length(hplots)) {
        type[data$plot==hplots[i]]<-1
    } 
    nohplots<-unique(data$plot[type==2])
    
    if (makeplot) plot(mod)  
    
    # To initialize, compute the predictions using the fixed part only. 
    # This will remain as the final predioction 
    # a) if nranp=0 (no randiom effects) and addResidual==0 
    # b) if level=0 (fixed part prediction is requested) and addResidual==0. 
    
    predall<-predict(mod,newdata=data, level=0)
    
    # If a higher level prediction is requested, then the realized random effects are  used.
    # If Some plots did not have measured heights for the preiction of random effects,
    # Then random effects are sampled from among the predictions. (Not using MVN(0,D)!)
    if (level>0 && nranp>0) {            
        predall[type==1]<-predict(mod,newdata=data[type==1,])
        
        D<-as.matrix(mod$modelStruct$reStruct[[1]])*mod$sigma^2
        if (length(nohplots)) {
            for (i in 1:length(nohplots)) {
                #       thiscoef<-fixef(mod)+mvrnorm(1,mu=rep(0,dim(D)[1]),Sigma=D)
                thiscoef<-coef(mod)[sample(1:mod$dims$ngrps[1],1),]
                if (length(formals(paste("HD",modelName,sep="")))==5) {
                    predall[data$plot==nohplots[i]]<-
                        eval(call(paste("HD",modelName,sep=""),
                                  d=data$d[data$plot==nohplots[i]],a=thiscoef[[1]],b=thiscoef[[2]],c=thiscoef[[3]],bh=bh))
                } else {
                    predall[data$plot==nohplots[i]]<-
                        eval(call(paste("HD",modelName,sep=""),
                                  d=data$d[data$plot==nohplots[i]],a=thiscoef[[1]],b=thiscoef[[2]],bh=bh))
                }         
                #                predall[data$plot==nohplots[i]] <- HDnaslund(d=data$d[data$plot==nohplots[i]],a=thiscoef[[1]],b=thiscoef[[2]])
            }
        }
    }
    
    # If level = 0 and AddResidual=True, then random effects are randomly assigned for each plot
    # before adding the tree level residual
    if (level==0 & nranp>0 & addResidual) {
        plots<-unique(data$plot)
        for (i in 1:length(plots)) {
            #       thiscoef<-fixef(mod)+mvrnorm(1,mu=rep(0,dim(D)[1]),Sigma=D)
            thiscoef<-coef(mod)[sample(1:mod$dims$ngrps[1],1),]
            if (length(formals(paste("HD",modelName,sep="")))==5) {
                predall[data$plot==plots[i]]<-
                    eval(call(paste("HD",modelName,sep=""),
                              d=data$d[data$plot==plots[i]],a=thiscoef[[1]],b=thiscoef[[2]],c=thiscoef[[3]],bh=bh))
            } else {
                predall[data$plot==plots[i]]<-
                    eval(call(paste("HD",modelName,sep=""),
                              d=data$d[data$plot==plots[i]],a=thiscoef[[1]],b=thiscoef[[2]],bh=bh))
            }
            
            #          predall[data$plot==plots[i]] <- HDnaslund(d=data$d[data$plot==plots[i]],a=thiscoef[[1]],b=thiscoef[[2]])
        }
    }
    
    # If addResidual==True, a random residual is added from a normal distribution 
    # using the estimated variance function.
    if (addResidual) {
        if (varf) {
            ressd<-mod$sigma*data$d^mod$modelStruct$varStruct
        } else if (!varf) {
            ressd<-mod$sigma
        }
        predall<-predall+rnorm(length(data$d),0,ressd)
    }
    
    type[!is.na(h)]<-0
    h[is.na(h)]<-predall[is.na(h)]
    
    list(h=h,imputed=is.na(data$h),model=mod,predType=type)
    
}
