startHDmicment2 <-
function(d,h,bh=1.3) {
    start<-coef(lm(I(d/(h-bh))~d))
    names(start)<-c("a","b")
    start
}
