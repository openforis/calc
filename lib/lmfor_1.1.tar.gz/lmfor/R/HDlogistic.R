HDlogistic <-
function(d,a,b,c,bh=1.3) {
    a/(1+b*exp(-c*d))+bh
}
