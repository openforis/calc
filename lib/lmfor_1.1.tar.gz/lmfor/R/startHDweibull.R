startHDweibull <-
function(d,h,bh=1.3) {
    a<-1.3*max(h-bh)
    start<-c(a,coef(lm(log(-log(1-(h-bh)/a))~log(d))))
    start[2]<-exp(start[2])
    names(start)<-c("a","b","c")
    start
}
