HDhossfeldIV <-
function(d,a,b,c,bh=1.3) {
    val<-a/(1+1/(b*d^c))+bh
    val
}
